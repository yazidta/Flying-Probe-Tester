# SilentStepStickKiCad
SilentStepStick TMC2209 imported to KiCad

Imported https://github.com/watterott/SilentStepStick into KiCad.
Added 3D Models from KiCads Library.

Attribution goes to https://github.com/watterott.

Open-Source and released under the Creative Commons Attribution Share-Alike License.
https://creativecommons.org/licenses/by-sa/4.0/
